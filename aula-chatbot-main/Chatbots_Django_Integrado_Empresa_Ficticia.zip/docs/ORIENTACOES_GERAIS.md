# Orientações gerais para os alunos

- Cada chatbot fica em uma pasta independente dentro de `projetos/`.
- Antes de executar, leia o `README.md` do projeto escolhido.
- Rode os comandos no diretório em que está o `manage.py`.
- O primeiro uso pode exigir `makemigrations` e `migrate`, conforme indicado no README.
- Cada projeto possui seu próprio banco SQLite.
- Para parar o servidor, pressione `Ctrl+C` no terminal.
- O servidor `runserver` é para desenvolvimento e ensino, não para produção.
