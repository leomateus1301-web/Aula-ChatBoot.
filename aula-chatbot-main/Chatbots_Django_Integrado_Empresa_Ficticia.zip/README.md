# Aula Chatbot — Coleção de projetos didáticos

Repositório do professor para projetos de chatbot usados nas aulas de Python e desenvolvimento web.

## Projetos

| Pasta | Projeto | Descrição |
|---|---|---|
| [`projetos/02-chatbot-django/`](projetos/02-chatbot-django/) | Chatbot Django básico | Projeto anterior convertido de Flask. |
| [`projetos/03-chat-integrado/`](projetos/03-chat-integrado/) | Chat Integrado | Site de empresa de tecnologia com chatbot flutuante, imagem de fundo e perguntas rápidas. |
| [`projetos/04-empresa-ficticia-chat/`](projetos/04-empresa-ficticia-chat/) | Empresa Fictícia com Chat | Site institucional com painel de chatbot integrado. |

Cada projeto tem `README.md` próprio, `requirements.txt` e documentação em `docs/`. Execute cada aplicação a partir da pasta dela, pois cada uma possui configuração Django e banco SQLite independentes.

## Executar um projeto
Entre na pasta desejada e siga o README daquele projeto. Exemplo:
```bash
cd projetos/03-chat-integrado
python -m pip install -r requirements.txt
python manage.py makemigrations
python manage.py migrate
python manage.py runserver 0.0.0.0:8000
```
Abra a porta 8000 no painel **Ports** do Codespaces.

## Atenção
Cada projeto usa a porta 8000 por padrão; pare o servidor atual com `Ctrl+C` antes de iniciar outro. Os bancos SQLite são locais a cada projeto/Codespace.
